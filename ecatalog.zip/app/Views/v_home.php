<div class="d-flex align-items-end row">
    <div class="col-sm-12">
        <div class="card-body">
            <button type="button" 
            class="btn btn-primary" 
            onclick="add_dialog();"
            >Tambah
            </button>
            <table id="table-datatable" class="table">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>University</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="basicModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-2">
                    <div class="col mb-0">
                        <label for="fist_name" class="form-label">First Name</label>
                        <input type="text" id="fist_name" class="form-control" placeholder="Enter First Name" />
                    </div>
                    <div class="col mb-0">
                        <label for="last_name" class="form-label">Last Name</label>
                        <input type="text" id="last_name" class="form-control" placeholder="Enter Last Name" />
                    </div>
                </div>
                <div class="row">
                    <div class="col mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="text" id="email" class="form-control" placeholder="xxxx@xxx.xx" />
                    </div>
                </div>
                <div class="row">
                    <div class="col mb-3">
                        <label for="university" class="form-label">University</label>
                        <input type="text" id="university" class="form-control" placeholder="Enter University" />
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
                <button type="button" class="btn btn-primary" onclick="prosesSimpan();">Simpan</button>
            </div>
        </div>
    </div>
</div>